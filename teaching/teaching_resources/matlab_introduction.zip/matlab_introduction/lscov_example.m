%% create and plot synthetic, noisy data
x=0:0.5:8;
y=4*x + 3 + randn(size(x));
plot(x,y,'ro')

%% set up matrices to create line of best fit
A=[x' ones(size(x'))];
B=y';

%X creates 'm' and 'b' for line of best fit, and STDX contains the standard
%error of these quantities
[X,STDX]=lscov(A,B)

%plot best fit line on top of data
hold on
plot(x,X(1)*x+X(2))
title(sprintf('Estimated slope: %3.2f +/- %3.2f \n Estimated y-int: %3.2f +/- %3.2f',X(1),STDX(1),X(2),STDX(2)),'fontsize',16)
set(gca,'fontsize',14)